package com.apexprime.app.ui.screens.auth

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexprime.app.data.auth.AuthRepository
import com.apexprime.app.data.auth.OtpResult
import com.apexprime.app.ui.components.GlassCard
import com.apexprime.app.ui.components.MeshGradientBackground
import com.apexprime.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OtpScreen(
    authRepo: AuthRepository,
    onSuccess: () -> Unit,
    onBack: () -> Unit
) {
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf(false) }
    var resendSeconds by remember { mutableIntStateOf(30) }
    val focusRequesters = List(6) { remember { FocusRequester() } }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val infinite = rememberInfiniteTransition(label = "bg")
    val dx by infinite.animateFloat(-25f, 25f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "x")
    val dy by infinite.animateFloat(-18f, 18f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "y")

    val checkScale = remember { Animatable(0f) }

    // Resend timer
    LaunchedEffect(resendSeconds) {
        if (resendSeconds > 0) {
            delay(1000)
            resendSeconds--
        }
    }

    // Auto verify when 6 digits
    LaunchedEffect(code) {
        if (code.length == 6 && !loading && !success) {
            loading = true
            error = null
            when (val r = authRepo.verifyOtp(code)) {
                is OtpResult.Success -> {
                    success = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    checkScale.animateTo(1.2f, tween(300))
                    checkScale.animateTo(1f, tween(150))
                    delay(700)
                    onSuccess()
                }
                is OtpResult.Error -> {
                    error = r.message
                    code = ""
                    focusRequesters[0].requestFocus()
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                is OtpResult.Locked -> {
                    error = "Too many attempts. Try again in 60s"
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            }
            loading = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.fillMaxSize(), dx, dy)

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (success) {
                Icon(
                    Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(80.dp).scale(checkScale.value)
                )
                Spacer(Modifier.height(16.dp))
                Text("Verified", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            } else {
                Text("Two-Factor Auth", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Enter the 6-digit code\n(Demo: 123456 always works)",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(32.dp))

                GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
                    // 6 digit boxes
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        repeat(6) { i ->
                            val char = code.getOrNull(i)?.toString() ?: ""
                            val isFocused = code.length == i
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(
                                        if (isFocused) AccentBlue.copy(alpha = 0.2f) else GlassWhite,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.5.dp,
                                        if (isFocused) AccentBlue else GlassBorder,
                                        RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    char,
                                    color = TextPrimary,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Hidden text field for input + paste
                    BasicTextField(
                        value = code,
                        onValueChange = { new ->
                            val filtered = new.filter { it.isDigit() }.take(6)
                            code = filtered
                            error = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp) // almost invisible but focusable
                            .focusRequester(focusRequesters[0]),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        textStyle = TextStyle(color = Color.Transparent),
                        cursorBrush = SolidColor(Color.Transparent),
                        singleLine = true
                    )

                    LaunchedEffect(Unit) {
                        delay(300)
                        focusRequesters[0].requestFocus()
                    }

                    if (error != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(error!!, color = ErrorRed, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }

                Spacer(Modifier.height(24.dp))

                if (resendSeconds > 0) {
                    Text("Resend code in ${resendSeconds}s", color = TextMuted, fontSize = 13.sp)
                } else {
                    TextButton(onClick = {
                        scope.launch {
                            authRepo.resendOtp()
                            resendSeconds = 30
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                    }) {
                        Text("Resend code", color = AccentBlue)
                    }
                }

                Spacer(Modifier.height(12.dp))
                TextButton(onClick = onBack) {
                    Text("Back to login", color = TextMuted, fontSize = 13.sp)
                }
            }
        }
    }
}
