package com.apexprime.app.data.remote

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class Provider(val label: String, val baseUrl: String, val defaultModel: String, val keyHint: String) {
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1/", "openai/gpt-6-astra", "sk-or-..."),
    OPENAI("OpenAI", "https://api.openai.com/v1/", "gpt-6-astra", "sk-proj-...");

    companion object {
        fun fromName(name: String?): Provider = entries.firstOrNull { it.name == name } ?: OPENROUTER
    }
}

class ApiConfig(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(
        context, "apex_api_secure", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var provider: Provider
        get() = Provider.fromName(prefs.getString("provider", null))
        set(v) = prefs.edit().putString("provider", v.name).apply()

    fun getKey(p: Provider): String {
        val saved = prefs.getString("key_${p.name}", null)
        if (saved != null) return saved
        // legacy key from v1 (OpenRouter only)
        return if (p == Provider.OPENROUTER) prefs.getString("openrouter_key", "") ?: "" else ""
    }

    fun setKey(p: Provider, v: String) {
        prefs.edit().putString("key_${p.name}", v.trim()).apply()
    }

    fun getModel(p: Provider): String {
        val saved = prefs.getString("model_${p.name}", null)
        return if (saved.isNullOrBlank()) p.defaultModel else saved
    }

    fun setModel(p: Provider, v: String) {
        prefs.edit().putString("model_${p.name}", v.trim().ifBlank { p.defaultModel }).apply()
    }

    val apiKey: String get() = getKey(provider)
    val model: String get() = getModel(provider)
    val baseUrl: String get() = provider.baseUrl
}
