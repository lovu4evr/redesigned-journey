package com.apexprime.app.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.apexprime.app.data.remote.Provider
import com.apexprime.app.domain.model.*
import com.apexprime.app.ui.components.GlassCard
import com.apexprime.app.ui.components.MeshGradientBackground
import com.apexprime.app.ui.theme.*

@Composable
fun ChatScreen(onLogout: () -> Unit = {}, vm: ChatViewModel = hiltViewModel()) {
    val state by vm.state.collectAsState()
    val listState = rememberLazyListState()
    val haptic = LocalHapticFeedback.current
    val infinite = rememberInfiniteTransition(label = "bg")
    val dx by infinite.animateFloat(-20f, 20f, infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse), label = "x")
    val dy by infinite.animateFloat(-15f, 15f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "y")

    val lastLen = state.messages.lastOrNull()?.content?.length ?: 0
    LaunchedEffect(state.messages.size, lastLen) {
        if (state.messages.isNotEmpty()) {
            listState.scrollToItem(state.messages.lastIndex)
        }
    }

    BackHandler(enabled = state.showSidebar || state.showSettings) {
        if (state.showSettings) vm.toggleSettings() else vm.toggleSidebar()
    }

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.fillMaxSize(), dx, dy)

        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().padding(12.dp, 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleSidebar() }) {
                    Icon(Icons.Rounded.Menu, null, tint = TextPrimary)
                }
                Text("Apex Prime", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            }

            // Mode chips
            ChipRow {
                AgentMode.entries.forEach { m ->
                    Chip(m.name.lowercase().replaceFirstChar { it.uppercase() }, state.mode == m) { vm.setMode(m) }
                }
            }
            // Personality chips
            ChipRow {
                Personality.entries.forEach { p ->
                    Chip(p.name.lowercase().replaceFirstChar { it.uppercase() }, state.personality == p) { vm.setPersonality(p) }
                }
            }

            // Messages
            if (state.messages.isEmpty()) {
                EmptyState(modifier = Modifier.weight(1f).fillMaxWidth(), onSuggestion = {
                    vm.onInputChange(it)
                    vm.send()
                })
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp, 8.dp)
                ) {
                    items(state.messages, key = { it.id }) { msg ->
                        MessageBubble(msg)
                        Spacer(Modifier.height(10.dp))
                    }
                    if (state.isStreaming && state.messages.lastOrNull()?.isStreaming != true) {
                        item {
                            Text("Thinking…", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }
            }

            // Error banner
            val err = state.error
            if (err != null) {
                Text(
                    err,
                    color = ErrorRed,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.dismissError() }
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }

            // Input bar
            GlassCard(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                cornerRadius = 22.dp,
                contentPadding = PaddingValues(8.dp, 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = state.input,
                        onValueChange = { vm.onInputChange(it) },
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp),
                        textStyle = TextStyle(color = TextPrimary, fontSize = 15.sp),
                        cursorBrush = SolidColor(AccentBlue),
                        maxLines = 5,
                        decorationBox = { inner ->
                            Box {
                                if (state.input.isEmpty()) Text("Message Apex…", color = TextMuted, fontSize = 15.sp)
                                inner()
                            }
                        }
                    )
                    if (state.isStreaming) {
                        IconButton(onClick = { vm.stopStreaming() }) {
                            Icon(Icons.Rounded.Stop, null, tint = ErrorRed)
                        }
                    } else {
                        IconButton(onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            vm.send()
                        }) {
                            Icon(Icons.AutoMirrored.Rounded.Send, null, tint = AccentBlue)
                        }
                    }
                }
            }
        }

        // Sidebar overlay (scrim + drawer)
        AnimatedVisibility(visible = state.showSidebar, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { vm.toggleSidebar() }
            )
        }
        AnimatedVisibility(
            visible = state.showSidebar,
            enter = slideInHorizontally { -it },
            exit = slideOutHorizontally { -it }
        ) {
            Sidebar(
                conversations = state.conversations,
                currentId = state.currentId,
                onNew = { vm.newChat(); haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                onOpen = { vm.openConversation(it) },
                onDelete = { vm.deleteConversation(it) },
                onSettings = { vm.toggleSettings() },
                onLogout = onLogout,
                onClose = { vm.toggleSidebar() }
            )
        }

        // Settings sheet
        if (state.showSettings) {
            SettingsSheet(
                initialProvider = vm.getProvider(),
                getKey = { vm.getKey(it) },
                getModel = { vm.getModel(it) },
                onSave = { p, k, m ->
                    vm.saveSettings(p, k, m)
                    vm.toggleSettings()
                },
                onClose = { vm.toggleSettings() }
            )
        }
    }
}

@Composable
private fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        content = content
    )
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) AccentBlue else TextMuted,
        fontSize = 12.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) AccentBlue.copy(0.18f) else GlassWhite.copy(alpha = 0.10f))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun MessageBubble(msg: ChatMessage) {
    val isUser = msg.role == MessageRole.USER
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    if (isUser) Brush.horizontalGradient(listOf(AccentBlue.copy(0.7f), AccentPurple.copy(0.7f)))
                    else Brush.horizontalGradient(listOf(GlassWhiteStrong, GlassWhite))
                )
                .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                .padding(12.dp, 10.dp)
        ) {
            SelectionContainer {
                val parts = msg.content.split("```")
                Column {
                    parts.forEachIndexed { i, part ->
                        if (i % 2 == 1) {
                            // Drop the language tag line (e.g. "kotlin") if present
                            val code = part.substringAfter('\n', part).trim()
                            Text(
                                code,
                                color = NeonCyan,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(0.35f), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            )
                        } else if (part.isNotBlank()) {
                            Text(part.trim(), color = TextPrimary, fontSize = 14.5.sp, lineHeight = 20.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier, onSuggestion: (String) -> Unit) {
    val suggestions = listOf(
        "Explain quantum computing simply",
        "Write a Kotlin coroutine example",
        "Plan my week productively",
        "Give me a savage roast of procrastination"
    )
    Column(
        modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Apex Prime", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("World's sharpest agent. Ask anything.", color = TextSecondary, fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        suggestions.forEach { s ->
            GlassCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                cornerRadius = 16.dp,
                contentPadding = PaddingValues(14.dp),
                onClick = { onSuggestion(s) }
            ) {
                Text(s, color = TextPrimary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun Sidebar(
    conversations: List<Conversation>,
    currentId: String?,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onSettings: () -> Unit,
    onLogout: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        Modifier
            .width(280.dp)
            .fillMaxHeight()
            .background(Color(0xF2101525))
            .systemBarsPadding()
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chats", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null, tint = TextMuted) }
        }
        Button(
            onClick = onNew,
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("New Chat")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(conversations, key = { it.id }) { c ->
                val selected = c.id == currentId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) AccentBlue.copy(0.2f) else Color.Transparent)
                        .clickable { onOpen(c.id) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        c.title.ifBlank { "New Chat" },
                        color = TextPrimary,
                        fontSize = 13.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onDelete(c.id) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Delete, null, tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        TextButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Settings, null, tint = TextMuted)
            Spacer(Modifier.width(8.dp))
            Text("Settings", color = TextMuted, modifier = Modifier.weight(1f))
        }
        TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.AutoMirrored.Rounded.Logout, null, tint = TextMuted)
            Spacer(Modifier.width(8.dp))
            Text("Log out", color = TextMuted, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun SettingsSheet(
    initialProvider: Provider,
    getKey: (Provider) -> String,
    getModel: (Provider) -> String,
    onSave: (Provider, String, String) -> Unit,
    onClose: () -> Unit
) {
    var provider by remember { mutableStateOf(initialProvider) }
    var key by remember(provider) { mutableStateOf(getKey(provider)) }
    var model by remember(provider) { mutableStateOf(getModel(provider)) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(0.6f)).clickable { onClose() }) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFF121826))
                .navigationBarsPadding()
                .imePadding()
                .padding(20.dp)
                .clickable(enabled = false) {}
        ) {
            Text("Settings", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Provider", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Provider.entries.forEach { p ->
                    Chip(p.label, provider == p) { provider = p }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("API Key (${provider.keyHint})", color = TextMuted, fontSize = 12.sp)
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Spacer(Modifier.height(12.dp))
            Text("Model (default: ${provider.defaultModel})", color = TextMuted, fontSize = 12.sp)
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { onSave(provider, key, model) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save") }
            Spacer(Modifier.height(8.dp))
        }
    }
}
