package com.apexprime.app.data.remote

import com.apexprime.app.domain.model.AgentMode
import com.apexprime.app.domain.model.ChatMessage
import com.apexprime.app.domain.model.MessageRole
import com.apexprime.app.domain.model.Personality
import com.apexprime.app.domain.model.StreamChunk
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class AiService(private val config: ApiConfig) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private fun systemPrompt(personality: Personality, mode: AgentMode): String {
        val base = when (personality) {
            Personality.CHILL -> "You are Apex Prime in Chill mode. Relaxed, friendly, witty. Keep answers light."
            Personality.PRO -> "You are Apex Prime, a precise, highly capable AI agent. Be clear, structured and professional."
            Personality.TEACHER -> "You are Apex Prime in Teacher mode. Explain step-by-step, use examples, check understanding."
            Personality.SAVAGE -> "You are Apex Prime in Savage mode. Direct, no fluff, brutally honest, high energy."
        }
        val extra = when (mode) {
            AgentMode.CHAT -> ""
            AgentMode.CODE -> " Focus on correct, well-explained code. Always put code in markdown code blocks."
            AgentMode.STUDY -> " Help the user learn: explain clearly, give examples and short quizzes."
            AgentMode.CREATE -> " Be imaginative and original. Offer polished creative output."
            AgentMode.RESEARCH -> " Be thorough and structured. Separate facts from uncertainty."
        }
        return base + extra
    }

    private fun parseError(raw: String, code: Int): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Exception) { "" }
        val hint = when (code) {
            401 -> "Invalid API key for ${config.provider.label}. Check provider and key in Settings."
            402 -> "Not enough ${config.provider.label} credits."
            429 -> "Rate limited or out of quota. Check your ${config.provider.label} billing."
            else -> ""
        }
        return listOf(hint, msg).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Request failed (HTTP $code)" }
    }

    /** Returns (text, error). Either may be null. */
    private fun parseChunk(data: String): Pair<String?, String?> {
        val json = JSONObject(data)
        val err = json.optJSONObject("error")
        if (err != null) return Pair(null, err.optString("message", "Stream error"))
        val choices = json.optJSONArray("choices") ?: return Pair(null, null)
        if (choices.length() == 0) return Pair(null, null)
        val delta = choices.getJSONObject(0).optJSONObject("delta") ?: return Pair(null, null)
        if (delta.isNull("content")) return Pair(null, null)
        val text = delta.optString("content", "")
        return Pair(if (text.isEmpty()) null else text, null)
    }

    /**
     * Streaming via Server-Sent Events (OpenRouter compatible).
     * Runs on Dispatchers.IO (network is not allowed on the main thread).
     */
    fun streamChat(
        history: List<ChatMessage>,
        personality: Personality,
        mode: AgentMode
    ): Flow<StreamChunk> = flow {
        val key = config.apiKey
        if (key.isBlank()) {
            val demo = "I'm Apex Prime running in offline demo mode.\n\nAdd your OpenRouter or OpenAI key in Settings to unlock full power.\n\nHow can I help you today?"
            for (word in demo.split(" ")) {
                emit(StreamChunk(word + " "))
                delay(40)
            }
            emit(StreamChunk("", done = true))
            return@flow
        }

        val provider = config.provider
        if (provider == Provider.OPENROUTER && key.startsWith("sk-proj-")) {
            emit(StreamChunk("", error = "This looks like an OpenAI key. Switch provider to OpenAI in Settings."))
            emit(StreamChunk("", done = true))
            return@flow
        }
        if (provider == Provider.OPENAI && key.startsWith("sk-or-")) {
            emit(StreamChunk("", error = "This looks like an OpenRouter key. Switch provider to OpenRouter in Settings."))
            emit(StreamChunk("", done = true))
            return@flow
        }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(personality, mode)))
        history.takeLast(20).forEach { m ->
            val role = when (m.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM -> "system"
            }
            messages.put(JSONObject().put("role", role).put("content", m.content))
        }

        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("stream", true)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val builder = Request.Builder()
            .url(provider.baseUrl + "chat/completions")
            .addHeader("Authorization", "Bearer $key")
        if (provider == Provider.OPENROUTER) {
            builder.addHeader("HTTP-Referer", "https://apexprime.app")
            builder.addHeader("X-Title", "Apex Prime")
        }
        val request = builder.post(body).build()

        val call = client.newCall(request)
        val handle = coroutineContext[Job]?.invokeOnCompletion { call.cancel() }
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val raw = response.body?.string().orEmpty()
                    emit(StreamChunk("", error = parseError(raw, response.code)))
                } else {
                    val source = response.body?.source()
                    if (source == null) {
                        emit(StreamChunk("", error = "Empty response from server"))
                    } else {
                        while (!source.exhausted()) {
                            val line = source.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val data = line.removePrefix("data:").trim()
                            if (data.isEmpty()) continue
                            if (data == "[DONE]") break
                            val parsed = try {
                                parseChunk(data)
                            } catch (_: Exception) {
                                Pair<String?, String?>(null, null)
                            }
                            val text = parsed.first
                            val error = parsed.second
                            if (error != null) {
                                emit(StreamChunk("", error = error))
                                break
                            }
                            if (text != null) emit(StreamChunk(text))
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            emit(StreamChunk("", error = "Network error. Check your internet connection."))
        } catch (e: Exception) {
            emit(StreamChunk("", error = e.message ?: "Unexpected error"))
        } finally {
            handle?.dispose()
        }
        emit(StreamChunk("", done = true))
    }.flowOn(Dispatchers.IO)
}
