# APEX PRIME — World's Sharpest Personal AI Agent

Glassmorphism • Splash • Onboarding • Auth + 2FA • Full Chat (streaming)

## Architecture
- **MVVM** + **Hilt**
- **Room** offline chat history
- **OpenRouter-compatible** streaming (SSE)
- **EncryptedSharedPreferences** for API key & sessions
- Clean packages: `ui/`, `data/`, `domain/`, `di/`

## Features
- Animated mesh gradient + frosted glass everywhere
- Splash + 4-page Onboarding
- Login / Sign-Up with validation & shake
- 6-digit OTP 2FA (demo code `123456`)
- Chat with sidebar, glass bubbles, code blocks
- Token streaming + Stop button
- Mode chips (Chat / Code / Study…)
- Personality (Chill / Pro / Teacher / Savage)
- Settings for OpenRouter key + model
- Empty state with suggestion chips

## Build APK

1. Open folder **ApexPrime** in Android Studio (Ladybug / newer)
2. Let Gradle sync (first time downloads deps)
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. Or terminal:
```bash
cd ApexPrime
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## First run
1. Splash → Onboarding → Login (any email + password ≥6)
2. OTP if 2FA (use **123456**)
3. Open Settings (sidebar) → paste **OpenRouter API key**
4. Chat!

## Notes
- API key is never hardcoded — stored encrypted on device
- Without key the agent runs in offline demo mode
- Package: `com.apexprime.app`

## Testing checklist
- [ ] Splash appears then navigates
- [ ] Onboarding Skip / Get Started works
- [ ] Login & Sign-Up validation + shake
- [ ] OTP accepts 123456 and shows success check
- [ ] New chat, send message, streaming appears
- [ ] Stop button cancels stream
- [ ] Sidebar open/close, delete conversation
- [ ] Settings saves API key
- [ ] App survives rotation & restart (session)
