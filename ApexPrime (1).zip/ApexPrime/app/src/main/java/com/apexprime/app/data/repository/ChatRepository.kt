package com.apexprime.app.data.repository

import com.apexprime.app.data.local.ApexDatabase
import com.apexprime.app.data.local.ConversationEntity
import com.apexprime.app.data.local.MessageEntity
import com.apexprime.app.data.remote.AiService
import com.apexprime.app.domain.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val db: ApexDatabase,
    private val ai: AiService
) {
    private val dao = db.chatDao()

    suspend fun getConversations(): List<Conversation> =
        dao.getConversations().map {
            Conversation(it.id, it.title, AgentMode.valueOf(it.mode), Personality.valueOf(it.personality),
                it.createdAt, it.updatedAt, it.isPinned)
        }

    suspend fun createConversation(mode: AgentMode = AgentMode.CHAT, personality: Personality = Personality.PRO): Conversation {
        val c = Conversation(mode = mode, personality = personality)
        dao.upsertConversation(ConversationEntity(c.id, c.title, c.mode.name, c.personality.name, c.createdAt, c.updatedAt, c.isPinned))
        return c
    }

    suspend fun renameConversation(id: String, title: String) {
        val list = dao.getConversations().find { it.id == id } ?: return
        dao.upsertConversation(list.copy(title = title, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteConversation(id: String) {
        dao.deleteConversation(id)
        dao.clearMessages(id)
    }

    suspend fun getMessages(conversationId: String): List<ChatMessage> =
        dao.getMessages(conversationId).map {
            ChatMessage(it.id, it.conversationId, MessageRole.valueOf(it.role), it.content, it.timestamp)
        }

    suspend fun saveMessage(msg: ChatMessage) {
        dao.insertMessage(MessageEntity(msg.id, msg.conversationId, msg.role.name, msg.content, msg.timestamp))
    }

    fun streamReply(history: List<ChatMessage>, personality: Personality): Flow<StreamChunk> =
        ai.streamChat(history, personality)
}
