package com.apexprime.app.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val ApexDarkScheme = darkColorScheme(
    primary=AccentBlue, onPrimary=Color.White, secondary=AccentPurple, onSecondary=Color.White,
    tertiary=AccentPink, background=SurfaceDark, onBackground=TextPrimary, surface=SurfaceDark,
    onSurface=TextPrimary, surfaceVariant=GlassWhite, onSurfaceVariant=TextSecondary, error=ErrorRed, onError=Color.White
)
@Composable fun ApexTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme=ApexDarkScheme, typography=ApexTypography, content=content)
}
