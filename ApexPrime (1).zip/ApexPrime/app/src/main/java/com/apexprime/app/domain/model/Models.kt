package com.apexprime.app.domain.model

import java.util.UUID

enum class MessageRole { USER, ASSISTANT, SYSTEM }

enum class AgentMode { CHAT, CODE, STUDY, CREATE, RESEARCH }

enum class Personality { CHILL, PRO, TEACHER, SAVAGE }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val reactions: List<String> = emptyList()
)

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Chat",
    val mode: AgentMode = AgentMode.CHAT,
    val personality: Personality = Personality.PRO,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

data class StreamChunk(val text: String, val done: Boolean = false)
