package com.apexprime.app.data.auth

data class AuthUser(
    val uid: String,
    val email: String,
    val displayName: String? = null,
    val is2faEnabled: Boolean = false
)

sealed class AuthResult {
    data class Success(val user: AuthUser, val needs2fa: Boolean = false) : AuthResult()
    data class Error(val message: String) : AuthResult()
    object Loading : AuthResult()
}

sealed class OtpResult {
    object Success : OtpResult()
    data class Error(val message: String) : OtpResult()
    object Locked : OtpResult()
}
