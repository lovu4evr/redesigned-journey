package com.apexprime.app.data
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
private val Context.dataStore by preferencesDataStore("apex_prefs")
object PrefsKeys { val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done") }
class PrefsRepository(private val context: Context) {
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[PrefsKeys.ONBOARDING_DONE] ?: false }
    suspend fun setOnboardingDone(done: Boolean = true) { context.dataStore.edit { it[PrefsKeys.ONBOARDING_DONE] = done } }
}
