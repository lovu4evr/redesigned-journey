package com.apexprime.app.data.auth

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

/**
 * Clean interface – swap LocalAuthRepository with FirebaseAuthRepository later.
 */
interface AuthRepository {
    val currentUser: StateFlow<AuthUser?>
    suspend fun login(email: String, password: String): AuthResult
    suspend fun signUp(email: String, password: String, name: String): AuthResult
    suspend fun verifyOtp(code: String): OtpResult
    suspend fun resendOtp(): Boolean
    suspend fun setupTotp(): TotpSetup
    suspend fun verifyTotpSetup(code: String): Boolean
    suspend fun logout()
    fun isSessionValid(): Boolean
    fun enableBiometric(enabled: Boolean)
    fun isBiometricEnabled(): Boolean
}

data class TotpSetup(val secret: String, val qrUrl: String, val backupCodes: List<String>)

class LocalAuthRepository(private val context: Context) : AuthRepository {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs = EncryptedSharedPreferences.create(
        context,
        "apex_secure_session",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _user = MutableStateFlow<AuthUser?>(null)
    override val currentUser: StateFlow<AuthUser?> = _user

    private var pendingOtp: String = "123456"          // demo OTP
    private var otpAttempts = 0
    private var lockUntil = 0L
    private var totpSecret: String? = null

    init {
        // Restore session
        val email = securePrefs.getString("email", null)
        val uid = securePrefs.getString("uid", null)
        if (email != null && uid != null && isSessionValid()) {
            _user.value = AuthUser(uid, email, securePrefs.getString("name", null),
                securePrefs.getBoolean("2fa", false))
        }
    }

    override suspend fun login(email: String, password: String): AuthResult {
        delay(800) // simulate network
        if (email.isBlank() || !email.contains("@")) return AuthResult.Error("Invalid email")
        if (password.length < 6) return AuthResult.Error("Password must be at least 6 characters")

        // Demo: accept any valid-looking credentials, or previously signed-up
        val savedPass = securePrefs.getString("pass_$email", null)
        if (savedPass != null && savedPass != password) {
            return AuthResult.Error("Wrong password")
        }
        if (savedPass == null) {
            // first time demo login – auto create
            securePrefs.edit().putString("pass_$email", password).apply()
        }

        val needs2fa = securePrefs.getBoolean("2fa_$email", false)
        val uid = securePrefs.getString("uid_$email", UUID.randomUUID().toString())
        securePrefs.edit()
            .putString("uid_$email", uid)
            .putString("email", email)
            .putString("uid", uid)
            .putLong("session_exp", System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000)
            .apply()

        val user = AuthUser(uid!!, email, securePrefs.getString("name_$email", null), needs2fa)
        if (!needs2fa) {
            _user.value = user
            securePrefs.edit().putBoolean("logged_in", true).apply()
        } else {
            // generate demo OTP
            pendingOtp = (100000..999999).random().toString()
            otpAttempts = 0
            // In real app send email/SMS. For demo we log it.
            android.util.Log.d("ApexAuth", "DEMO OTP = $pendingOtp")
        }
        return AuthResult.Success(user, needs2fa = needs2fa)
    }

    override suspend fun signUp(email: String, password: String, name: String): AuthResult {
        delay(900)
        if (email.isBlank() || !email.contains("@")) return AuthResult.Error("Invalid email")
        if (password.length < 6) return AuthResult.Error("Password too short (min 6)")
        if (name.isBlank()) return AuthResult.Error("Name required")
        if (securePrefs.contains("pass_$email")) return AuthResult.Error("Account already exists")

        val uid = UUID.randomUUID().toString()
        securePrefs.edit()
            .putString("pass_$email", password)
            .putString("uid_$email", uid)
            .putString("name_$email", name)
            .putString("email", email)
            .putString("uid", uid)
            .putString("name", name)
            .putLong("session_exp", System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000)
            .putBoolean("logged_in", true)
            .apply()
        val user = AuthUser(uid, email, name, false)
        _user.value = user
        return AuthResult.Success(user)
    }

    override suspend fun verifyOtp(code: String): OtpResult {
        if (System.currentTimeMillis() < lockUntil) return OtpResult.Locked
        delay(500)
        if (code == pendingOtp || code == "123456") { // 123456 always works in demo
            otpAttempts = 0
            val email = securePrefs.getString("email", "")!!
            val uid = securePrefs.getString("uid", "")!!
            _user.value = AuthUser(uid, email, securePrefs.getString("name", null), true)
            securePrefs.edit().putBoolean("logged_in", true).apply()
            return OtpResult.Success
        }
        otpAttempts++
        if (otpAttempts >= 5) {
            lockUntil = System.currentTimeMillis() + 60_000
            return OtpResult.Locked
        }
        return OtpResult.Error("Invalid code. ${5 - otpAttempts} attempts left")
    }

    override suspend fun resendOtp(): Boolean {
        delay(400)
        pendingOtp = (100000..999999).random().toString()
        otpAttempts = 0
        android.util.Log.d("ApexAuth", "NEW DEMO OTP = $pendingOtp")
        return true
    }

    override suspend fun setupTotp(): TotpSetup {
        val secret = "JBSWY3DPEHPK3PXP" // demo secret
        totpSecret = secret
        val email = securePrefs.getString("email", "user@apex")
        val qr = "otpauth://totp/ApexPrime:$email?secret=$secret&issuer=ApexPrime"
        val backups = List(8) { "%04d-%04d".format((0..9999).random(), (0..9999).random()) }
        return TotpSetup(secret, qr, backups)
    }

    override suspend fun verifyTotpSetup(code: String): Boolean {
        delay(400)
        // Demo: accept 123456 or any 6 digit
        if (code.length == 6) {
            val email = securePrefs.getString("email", "") ?: return false
            securePrefs.edit().putBoolean("2fa_$email", true).putBoolean("2fa", true).apply()
            return true
        }
        return false
    }

    override suspend fun logout() {
        securePrefs.edit()
            .remove("logged_in")
            .remove("session_exp")
            .apply()
        _user.value = null
    }

    override fun isSessionValid(): Boolean {
        val exp = securePrefs.getLong("session_exp", 0)
        return securePrefs.getBoolean("logged_in", false) && System.currentTimeMillis() < exp
    }

    override fun enableBiometric(enabled: Boolean) {
        securePrefs.edit().putBoolean("biometric", enabled).apply()
    }

    override fun isBiometricEnabled() = securePrefs.getBoolean("biometric", false)
}
