package com.apexprime.app.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.apexprime.app.data.remote.ApiConfig
import com.apexprime.app.data.repository.ChatRepository
import com.apexprime.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val conversations: List<Conversation> = emptyList(),
    val currentId: String? = null,
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isStreaming: Boolean = false,
    val mode: AgentMode = AgentMode.CHAT,
    val personality: Personality = Personality.PRO,
    val showSidebar: Boolean = false,
    val showSettings: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repo: ChatRepository,
    private val apiConfig: ApiConfig
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private var streamJob: Job? = null

    init { refreshConversations() }

    fun refreshConversations() = viewModelScope.launch {
        val list = repo.getConversations()
        _state.update { it.copy(conversations = list) }
        if (_state.value.currentId == null && list.isNotEmpty()) {
            openConversation(list.first().id)
        }
    }

    fun openConversation(id: String) = viewModelScope.launch {
        val msgs = repo.getMessages(id)
        val conv = _state.value.conversations.find { it.id == id }
        _state.update {
            it.copy(
                currentId = id,
                messages = msgs,
                mode = conv?.mode ?: AgentMode.CHAT,
                personality = conv?.personality ?: Personality.PRO,
                showSidebar = false
            )
        }
    }

    fun newChat() = viewModelScope.launch {
        val c = repo.createConversation(_state.value.mode, _state.value.personality)
        refreshConversations()
        openConversation(c.id)
    }

    fun onInputChange(t: String) = _state.update { it.copy(input = t) }

    fun send() {
        val text = _state.value.input.trim()
        if (text.isEmpty() || _state.value.isStreaming) return
        viewModelScope.launch {
            val existingId = _state.value.currentId
            val cid: String = existingId ?: repo.createConversation(_state.value.mode, _state.value.personality).id
            if (existingId == null) {
                _state.update { it.copy(currentId = cid) }
                refreshConversations()
            }
            val userMsg = ChatMessage(conversationId = cid, role = MessageRole.USER, content = text)
            repo.saveMessage(userMsg)
            _state.update {
                it.copy(
                    input = "",
                    messages = it.messages + userMsg,
                    isStreaming = true,
                    currentId = cid
                )
            }

            val assistantId = UUID.randomUUID().toString()
            var full = ""
            val history = _state.value.messages
            streamJob = viewModelScope.launch {
                repo.streamReply(history, _state.value.personality).collect { chunk ->
                    if (chunk.done) {
                        val finalMsg = ChatMessage(assistantId, cid, MessageRole.ASSISTANT, full)
                        repo.saveMessage(finalMsg)
                        _state.update {
                            it.copy(
                                messages = it.messages.filter { m -> m.id != assistantId } + finalMsg,
                                isStreaming = false
                            )
                        }
                        // auto-title first message
                        if (history.size <= 1) {
                            repo.renameConversation(cid, text.take(40))
                            refreshConversations()
                        }
                    } else {
                        full += chunk.text
                        val streamingMsg = ChatMessage(assistantId, cid, MessageRole.ASSISTANT, full, isStreaming = true)
                        _state.update {
                            val without = it.messages.filter { m -> m.id != assistantId }
                            it.copy(messages = without + streamingMsg)
                        }
                    }
                }
            }
        }
    }

    fun stopStreaming() {
        streamJob?.cancel()
        _state.update { it.copy(isStreaming = false) }
    }

    fun setMode(m: AgentMode) = _state.update { it.copy(mode = m) }
    fun setPersonality(p: Personality) = _state.update { it.copy(personality = p) }
    fun toggleSidebar() = _state.update { it.copy(showSidebar = !it.showSidebar) }
    fun toggleSettings() = _state.update { it.copy(showSettings = !it.showSettings) }

    fun deleteConversation(id: String) = viewModelScope.launch {
        repo.deleteConversation(id)
        if (_state.value.currentId == id) _state.update { it.copy(currentId = null, messages = emptyList()) }
        refreshConversations()
    }

    fun saveApiKey(key: String) { apiConfig.apiKey = key }
    fun getApiKey() = apiConfig.apiKey
    fun saveModel(m: String) { apiConfig.model = m }
    fun getModel() = apiConfig.model
}
