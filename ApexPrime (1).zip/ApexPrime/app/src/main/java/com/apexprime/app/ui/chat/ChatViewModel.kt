package com.apexprime.app.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.apexprime.app.data.remote.ApiConfig
import com.apexprime.app.data.repository.ChatRepository
import com.apexprime.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val conversations: List<Conversation> = emptyList(),
    val currentId: String? = null,
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isStreaming: Boolean = false,
    val mode: AgentMode = AgentMode.CHAT,
    val personality: Personality = Personality.PRO,
    val showSidebar: Boolean = false,
    val showSettings: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repo: ChatRepository,
    private val apiConfig: ApiConfig
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private var streamJob: Job? = null

    init { refreshConversations() }

    fun refreshConversations() = viewModelScope.launch {
        val list = repo.getConversations()
        _state.update { it.copy(conversations = list) }
        if (_state.value.currentId == null && list.isNotEmpty()) {
            openConversation(list.first().id)
        }
    }

    fun openConversation(id: String) = viewModelScope.launch {
        if (_state.value.isStreaming) stopStreaming()
        val msgs = repo.getMessages(id)
        val conv = _state.value.conversations.find { it.id == id }
        _state.update {
            it.copy(
                currentId = id,
                messages = msgs,
                mode = conv?.mode ?: it.mode,
                personality = conv?.personality ?: it.personality,
                showSidebar = false,
                error = null
            )
        }
    }

    fun newChat() = viewModelScope.launch {
        if (_state.value.isStreaming) stopStreaming()
        val c = repo.createConversation(_state.value.mode, _state.value.personality)
        _state.update { it.copy(currentId = c.id, messages = emptyList(), showSidebar = false, error = null) }
        refreshConversations()
    }

    fun onInputChange(t: String) = _state.update { it.copy(input = t) }

    fun send() {
        val text = _state.value.input.trim()
        if (text.isEmpty() || _state.value.isStreaming) return
        viewModelScope.launch {
            val existingId = _state.value.currentId
            val cid: String = existingId
                ?: repo.createConversation(_state.value.mode, _state.value.personality).id
            if (existingId == null) {
                _state.update { it.copy(currentId = cid) }
                refreshConversations()
            }
            val userMsg = ChatMessage(conversationId = cid, role = MessageRole.USER, content = text)
            repo.saveMessage(userMsg)
            _state.update {
                it.copy(
                    input = "",
                    messages = it.messages + userMsg,
                    isStreaming = true,
                    currentId = cid,
                    error = null
                )
            }

            val assistantId = UUID.randomUUID().toString()
            var full = ""
            val history = _state.value.messages
            val personality = _state.value.personality
            val mode = _state.value.mode

            streamJob = viewModelScope.launch {
                repo.streamReply(history, personality, mode)
                    .catch { e ->
                        _state.update {
                            it.copy(
                                error = e.message ?: "Something went wrong",
                                isStreaming = false,
                                messages = it.messages.filter { m -> m.id != assistantId }
                            )
                        }
                    }
                    .collect { chunk ->
                        if (chunk.error != null) {
                            _state.update {
                                it.copy(
                                    error = chunk.error,
                                    messages = it.messages.filter { m -> m.id != assistantId }
                                )
                            }
                        } else if (chunk.done) {
                            if (full.isNotBlank()) {
                                val finalMsg = ChatMessage(assistantId, cid, MessageRole.ASSISTANT, full)
                                repo.saveMessage(finalMsg)
                                _state.update {
                                    it.copy(
                                        messages = it.messages.filter { m -> m.id != assistantId } + finalMsg,
                                        isStreaming = false
                                    )
                                }
                                if (history.size <= 1) {
                                    repo.renameConversation(cid, text.take(40))
                                    refreshConversations()
                                }
                            } else {
                                _state.update {
                                    it.copy(
                                        messages = it.messages.filter { m -> m.id != assistantId },
                                        isStreaming = false
                                    )
                                }
                            }
                        } else {
                            full += chunk.text
                            val streamingMsg = ChatMessage(assistantId, cid, MessageRole.ASSISTANT, full, isStreaming = true)
                            _state.update {
                                val without = it.messages.filter { m -> m.id != assistantId }
                                it.copy(messages = without + streamingMsg)
                            }
                        }
                    }
            }
        }
    }

    fun stopStreaming() {
        streamJob?.cancel()
        streamJob = null
        viewModelScope.launch {
            val partial = _state.value.messages.lastOrNull { it.isStreaming }
            if (partial != null && partial.content.isNotBlank()) {
                val finished = partial.copy(isStreaming = false)
                repo.saveMessage(finished)
                _state.update { st ->
                    st.copy(
                        messages = st.messages.map { m -> if (m.id == finished.id) finished else m },
                        isStreaming = false
                    )
                }
            } else {
                _state.update { st ->
                    st.copy(messages = st.messages.filter { !it.isStreaming }, isStreaming = false)
                }
            }
        }
    }

    fun dismissError() = _state.update { it.copy(error = null) }
    fun setMode(m: AgentMode) = _state.update { it.copy(mode = m) }
    fun setPersonality(p: Personality) = _state.update { it.copy(personality = p) }
    fun toggleSidebar() = _state.update { it.copy(showSidebar = !it.showSidebar) }
    fun toggleSettings() = _state.update { it.copy(showSettings = !it.showSettings) }

    fun deleteConversation(id: String) = viewModelScope.launch {
        if (_state.value.currentId == id && _state.value.isStreaming) {
            streamJob?.cancel()
            _state.update { it.copy(isStreaming = false) }
        }
        repo.deleteConversation(id)
        if (_state.value.currentId == id) _state.update { it.copy(currentId = null, messages = emptyList()) }
        refreshConversations()
    }

    fun saveApiKey(key: String) { apiConfig.apiKey = key }
    fun getApiKey() = apiConfig.apiKey
    fun saveModel(m: String) { apiConfig.model = m }
    fun getModel() = apiConfig.model
}
