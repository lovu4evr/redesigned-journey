package com.apexprime.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import com.apexprime.app.data.PrefsRepository
import com.apexprime.app.data.auth.AuthRepository
import com.apexprime.app.ui.chat.ChatScreen
import com.apexprime.app.ui.screens.OnboardingScreen
import com.apexprime.app.ui.screens.SplashScreen
import com.apexprime.app.ui.screens.auth.LoginScreen
import com.apexprime.app.ui.screens.auth.OtpScreen
import com.apexprime.app.ui.theme.ApexTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class AppScreen {
    object Splash : AppScreen()
    object Onboarding : AppScreen()
    object Login : AppScreen()
    object Otp : AppScreen()
    object Chat : AppScreen()
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var authRepo: AuthRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        val systemSplash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        var keep = true
        systemSplash.setKeepOnScreenCondition { keep }

        val prefs = PrefsRepository(applicationContext)

        setContent {
            ApexTheme {
                var screen by remember { mutableStateOf<AppScreen>(AppScreen.Splash) }
                val scope = rememberCoroutineScope()

                LaunchedEffect(Unit) { keep = false }

                when (screen) {
                    AppScreen.Splash -> SplashScreen {
                        scope.launch {
                            val onboardingDone = prefs.onboardingDone.first()
                            screen = when {
                                !onboardingDone -> AppScreen.Onboarding
                                authRepo.isSessionValid() -> AppScreen.Chat
                                else -> AppScreen.Login
                            }
                        }
                    }
                    AppScreen.Onboarding -> OnboardingScreen {
                        scope.launch { prefs.setOnboardingDone(true) }
                        screen = AppScreen.Login
                    }
                    AppScreen.Login -> LoginScreen(
                        authRepo = authRepo,
                        onLoginSuccess = { needs2fa -> screen = if (needs2fa) AppScreen.Otp else AppScreen.Chat },
                        onNavigateToChat = { screen = AppScreen.Chat }
                    )
                    AppScreen.Otp -> OtpScreen(
                        authRepo = authRepo,
                        onSuccess = { screen = AppScreen.Chat },
                        onBack = { screen = AppScreen.Login }
                    )
                    AppScreen.Chat -> ChatScreen(onLogout = {
                        scope.launch {
                            authRepo.logout()
                            screen = AppScreen.Login
                        }
                    })
                }
            }
        }
    }
}
