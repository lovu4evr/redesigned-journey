package com.apexprime.app.di

import android.content.Context
import androidx.room.Room
import com.apexprime.app.data.local.ApexDatabase
import com.apexprime.app.data.remote.AiService
import com.apexprime.app.data.remote.ApiConfig
import com.apexprime.app.data.auth.AuthRepository
import com.apexprime.app.data.auth.LocalAuthRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): ApexDatabase =
        Room.databaseBuilder(ctx, ApexDatabase::class.java, "apex.db").build()

    @Provides @Singleton
    fun provideApiConfig(@ApplicationContext ctx: Context) = ApiConfig(ctx)

    @Provides @Singleton
    fun provideAiService(config: ApiConfig) = AiService(config)

    @Provides @Singleton
    fun provideAuth(@ApplicationContext ctx: Context): AuthRepository = LocalAuthRepository(ctx)
}
