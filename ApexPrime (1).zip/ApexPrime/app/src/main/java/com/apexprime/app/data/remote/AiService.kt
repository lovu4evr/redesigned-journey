package com.apexprime.app.data.remote

import com.apexprime.app.domain.model.ChatMessage
import com.apexprime.app.domain.model.MessageRole
import com.apexprime.app.domain.model.Personality
import com.apexprime.app.domain.model.StreamChunk
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiService(private val config: ApiConfig) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun systemPrompt(personality: Personality): String = when (personality) {
        Personality.CHILL -> "You are Apex Prime in Chill mode. Relaxed, friendly, witty. Keep answers light."
        Personality.PRO -> "You are Apex Prime, a precise, highly capable AI agent. Be clear, structured and professional."
        Personality.TEACHER -> "You are Apex Prime in Teacher mode. Explain step-by-step, use examples, check understanding."
        Personality.SAVAGE -> "You are Apex Prime in Savage mode. Direct, no fluff, brutally honest, high energy."
    }

    /**
     * Streaming via Server-Sent Events (OpenRouter compatible).
     * Falls back to simulated stream if no API key.
     */
    fun streamChat(
        history: List<ChatMessage>,
        personality: Personality
    ): Flow<StreamChunk> = flow {
        val key = config.apiKey
        if (key.isBlank()) {
            // Demo offline stream
            val demo = "I'm Apex Prime running in offline demo mode.\n\nAdd your OpenRouter key in Settings to unlock full power.\n\nHow can I help you today?"
            for (word in demo.split(" ")) {
                emit(StreamChunk(word + " "))
                delay(40)
            }
            emit(StreamChunk("", done = true))
            return@flow
        }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(personality)))
        history.takeLast(20).forEach { m ->
            val role = when (m.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM -> "system"
            }
            messages.put(JSONObject().put("role", role).put("content", m.content))
        }

        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("stream", true)
            .put("temperature", 0.7)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(config.baseUrl + "chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("HTTP-Referer", "https://apexprime.app")
            .addHeader("X-Title", "Apex Prime")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                emit(StreamChunk("Error ${response.code}: ${response.message}"))
                emit(StreamChunk("", done = true))
                return@flow
            }
            val source = response.body?.source() ?: return@flow
            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                if (line.startsWith("data: ")) {
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") {
                        emit(StreamChunk("", done = true))
                        break
                    }
                    try {
                        val json = JSONObject(data)
                        val delta = json.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("delta")
                        if (delta.has("content")) {
                            emit(StreamChunk(delta.getString("content")))
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }
}
