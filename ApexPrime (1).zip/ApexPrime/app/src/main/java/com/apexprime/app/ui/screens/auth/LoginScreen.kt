package com.apexprime.app.ui.screens.auth

import androidx.compose.animation.core.*
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexprime.app.data.auth.AuthRepository
import com.apexprime.app.data.auth.AuthResult
import com.apexprime.app.ui.components.GlassButton
import com.apexprime.app.ui.components.GlassCard
import com.apexprime.app.ui.components.MeshGradientBackground
import com.apexprime.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    authRepo: AuthRepository,
    onLoginSuccess: (needs2fa: Boolean) -> Unit,
    onNavigateToChat: () -> Unit
) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var shake by remember { mutableStateOf(0) }

    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val focus = LocalFocusManager.current
    val infinite = rememberInfiniteTransition(label = "bg")
    val dx by infinite.animateFloat(-30f, 30f, infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Reverse), label = "x")
    val dy by infinite.animateFloat(-20f, 20f, infiniteRepeatable(tween(13000, easing = LinearEasing), RepeatMode.Reverse), label = "y")

    // Shake animation
    val shakeOffset by animateFloatAsState(
        targetValue = if (shake > 0) (if (shake % 2 == 0) 12f else -12f) else 0f,
        animationSpec = tween(50),
        finishedListener = { if (shake > 0) shake-- },
        label = "shake"
    )

    fun triggerError(msg: String) {
        error = msg
        shake = 6
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    fun submit() {
        error = null
        if (email.isBlank() || !email.contains("@")) { triggerError("Enter a valid email"); return }
        if (password.length < 6) { triggerError("Password min 6 characters"); return }
        if (!isLogin && name.isBlank()) { triggerError("Name required"); return }

        loading = true
        scope.launch {
            val result = if (isLogin) authRepo.login(email.trim(), password)
                         else authRepo.signUp(email.trim(), password, name.trim())
            loading = false
            when (result) {
                is AuthResult.Success -> {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    if (result.needs2fa) onLoginSuccess(true)
                    else onNavigateToChat()
                }
                is AuthResult.Error -> triggerError(result.message)
                else -> {}
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.fillMaxSize(), dx, dy)

        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "APEX PRIME",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (isLogin) "Welcome back" else "Create your account",
                color = TextSecondary,
                fontSize = 15.sp
            )
            Spacer(Modifier.height(28.dp))

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer { translationX = shakeOffset },
                cornerRadius = 26.dp
            ) {
                AnimatedContent(
                    targetState = isLogin,
                    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                    label = "form"
                ) { loginMode ->
                    Column {
                        if (!loginMode) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it; error = null },
                                label = { Text("Full name") },
                                leadingIcon = { Icon(Icons.Rounded.Person, null, tint = AccentBlue) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = glassFieldColors(),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                            )
                            Spacer(Modifier.height(12.dp))
                        }

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it; error = null },
                            label = { Text("Email") },
                            leadingIcon = { Icon(Icons.Rounded.Email, null, tint = AccentBlue) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = glassFieldColors(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                        )
                        Spacer(Modifier.height(12.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it; error = null },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Rounded.Lock, null, tint = AccentBlue) },
                            trailingIcon = {
                                IconButton(onClick = { showPass = !showPass }) {
                                    Icon(
                                        if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                        null, tint = TextMuted
                                    )
                                }
                            },
                            visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = glassFieldColors(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { submit() })
                        )

                        if (loginMode) {
                            TextButton(
                                onClick = { /* TODO forgot */ },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("Forgot password?", color = AccentBlue, fontSize = 13.sp)
                            }
                        } else Spacer(Modifier.height(8.dp))

                        if (error != null) {
                            Text(error!!, color = ErrorRed, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }

                        Spacer(Modifier.height(16.dp))

                        GlassButton(
                            text = if (loading) "Please wait…" else if (loginMode) "Log In" else "Sign Up",
                            onClick = { if (!loading) submit() },
                            modifier = Modifier.fillMaxWidth(),
                            primary = true
                        )

                        Spacer(Modifier.height(12.dp))

                        // Google placeholder
                        OutlinedButton(
                            onClick = { triggerError("Google Sign-In coming in full Firebase setup") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                        ) {
                            Text("Continue with Google")
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            TextButton(onClick = {
                isLogin = !isLogin
                error = null
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }) {
                Text(
                    if (isLogin) "New here? Create account" else "Already have an account? Log in",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = AccentBlue.copy(alpha = 0.7f),
    unfocusedBorderColor = GlassBorder,
    focusedLabelColor = AccentBlue,
    unfocusedLabelColor = TextMuted,
    cursorColor = AccentBlue,
    focusedContainerColor = GlassWhite.copy(alpha = 0.15f),
    unfocusedContainerColor = GlassWhite.copy(alpha = 0.08f)
)
