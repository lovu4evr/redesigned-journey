package com.apexprime.app.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.apexprime.app.ui.components.*
import com.apexprime.app.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

data class OnboardPage(val title: String, val desc: String, val icon: ImageVector, val accent: Color)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val pages = listOf(
        OnboardPage("Meet Apex Prime", "Your personal AI agent that thinks, plans and acts.", Icons.Rounded.AutoAwesome, AccentBlue),
        OnboardPage("Ask Anything", "From complex research to daily tasks — just talk.", Icons.Rounded.Bolt, AccentPurple),
        OnboardPage("Build Anything", "Code, documents, plans and more. Apex builds with you.", Icons.Rounded.Code, NeonCyan),
        OnboardPage("Secure by Design", "Your data stays on device. You stay in control.", Icons.Rounded.Security, AccentPink)
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val inf = rememberInfiniteTransition(label = "m")
    val dx by inf.animateFloat(-35f, 35f, infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse), label = "x")
    val dy by inf.animateFloat(-25f, 25f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "y")

    Box(Modifier.fillMaxSize()) {
        MeshGradientBackground(Modifier.fillMaxSize(), dx, dy)
        Column(Modifier.fillMaxSize().padding(24.dp, 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton({ haptic.performHapticFeedback(HapticFeedbackType.LongPress); onFinished() }) {
                    Text("Skip", color = TextMuted)
                }
            }
            HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { page ->
                val p = pages[page]
                val off = (pager.currentPage - page) + pager.currentPageOffsetFraction
                val sc = 1f - abs(off)*0.1f
                Column(Modifier.fillMaxSize().graphicsLayer { scaleX = sc; scaleY = sc; alpha = 1f-abs(off)*0.35f }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Box(Modifier.size(110.dp).graphicsLayer { translationY = sin(off*2)*10f }, contentAlignment = Alignment.Center) {
                        GlassCard(Modifier.size(90.dp), 50.dp, PaddingValues(0.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(p.icon, null, tint = p.accent, modifier = Modifier.size(42.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    GlassCard(Modifier.fillMaxWidth(), 24.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(p.title, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(10.dp))
                            Text(p.desc, color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 20.sp)
                        }
                    }
                }
            }
            Row(Modifier.padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pages.size) { i ->
                    Box(Modifier.padding(4.dp).height(8.dp).width(if (pager.currentPage==i) 20.dp else 8.dp).background(if (pager.currentPage==i) AccentBlue else TextMuted.copy(0.35f), CircleShape))
                }
            }
            GlassButton(if (pager.currentPage == pages.lastIndex) "Get Started" else "Next", {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                if (pager.currentPage == pages.lastIndex) onFinished()
                else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
    }
}
