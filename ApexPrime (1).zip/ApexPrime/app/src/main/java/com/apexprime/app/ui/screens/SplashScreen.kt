package com.apexprime.app.ui.screens
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexprime.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.3f) }
    val alpha = remember { Animatable(0f) }
    val tag = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        alpha.animateTo(1f, tween(500))
        delay(300); tag.animateTo(1f, tween(400))
        delay(1000); alpha.animateTo(0f, tween(350)); tag.animateTo(0f, tween(300))
        onFinished()
    }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(100.dp).graphicsLayer { scaleX = scale.value; scaleY = scale.value; this.alpha = alpha.value }, contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Offset(size.width/2, size.height/2)
                    drawCircle(Brush.radialGradient(listOf(AccentBlue.copy(0.45f), Color.Transparent)), size.minDimension*0.5f, c)
                    val p = Path().apply {
                        moveTo(c.x, c.y-36f); lineTo(c.x+30f, c.y+28f); lineTo(c.x+12f, c.y+28f)
                        lineTo(c.x, c.y-6f); lineTo(c.x-12f, c.y+28f); lineTo(c.x-30f, c.y+28f); close()
                    }
                    drawPath(p, Color.White)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("APEX PRIME", color = TextPrimary.copy(alpha.value), fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Text("World's #1 Agent", color = AccentBlue.copy(tag.value), fontSize = 13.sp, letterSpacing = 1.sp)
        }
    }
}
