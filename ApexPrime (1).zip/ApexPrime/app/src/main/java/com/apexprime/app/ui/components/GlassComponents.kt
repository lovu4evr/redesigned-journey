package com.apexprime.app.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.apexprime.app.ui.theme.*

@Composable
fun GlassCard(modifier: Modifier = Modifier, cornerRadius: Dp = 24.dp, contentPadding: PaddingValues = PaddingValues(20.dp), onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(cornerRadius)
    val haptic = LocalHapticFeedback.current
    Box(modifier.clip(shape).background(GlassWhite, shape).border(1.dp, GlassBorder, shape)
        .then(if (onClick != null) Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() } else Modifier)
        .padding(contentPadding)) { content() }
}

@Composable
fun GlassButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = true) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(22.dp)
    val bg = if (primary) Brush.horizontalGradient(listOf(AccentBlue.copy(0.85f), AccentPurple.copy(0.85f))) else Brush.horizontalGradient(listOf(GlassWhiteStrong, GlassWhiteStrong))
    Box(modifier.clip(shape).background(bg, shape).border(1.dp, GlassBorder, shape).clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() }.padding(horizontal = 28.dp, vertical = 14.dp), contentAlignment = Alignment.Center) {
        Text(text, color = TextPrimary, style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold))
    }
}

@Composable
fun MeshGradientBackground(modifier: Modifier = Modifier, offsetX: Float = 0f, offsetY: Float = 0f) {
    Box(modifier.drawBehind {
        drawRect(Color(0xFF070B14))
        drawCircle(Brush.radialGradient(listOf(Color(0xFF6C8CFF).copy(0.35f), Color.Transparent), Offset(size.width*0.2f+offsetX, size.height*0.25f+offsetY), size.minDimension*0.55f), size.minDimension*0.55f, Offset(size.width*0.2f+offsetX, size.height*0.25f+offsetY))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFA78BFA).copy(0.30f), Color.Transparent), Offset(size.width*0.8f-offsetX*0.7f, size.height*0.35f+offsetY*0.5f), size.minDimension*0.5f), size.minDimension*0.5f, Offset(size.width*0.8f-offsetX*0.7f, size.height*0.35f+offsetY*0.5f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFF6BCB).copy(0.22f), Color.Transparent), Offset(size.width*0.5f+offsetX*0.4f, size.height*0.75f-offsetY*0.3f), size.minDimension*0.6f), size.minDimension*0.6f, Offset(size.width*0.5f+offsetX*0.4f, size.height*0.75f-offsetY*0.3f))
    })
}
