# Keep Compose & DataStore
-keep class androidx.compose.** { *; }
-keep class androidx.datastore.** { *; }
